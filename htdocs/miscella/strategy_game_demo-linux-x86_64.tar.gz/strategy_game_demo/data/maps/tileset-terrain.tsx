<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="tileset-terrain" tilewidth="56" tileheight="56" spacing="8" margin="4" tilecount="16" columns="4">
 <image source="tileset-terrain.png" width="256" height="256"/>
</tileset>
