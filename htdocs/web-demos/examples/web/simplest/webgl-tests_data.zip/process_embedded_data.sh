#!/bin/bash
set -eu

image-to-pascal GameImages --output=../code/ *.png
